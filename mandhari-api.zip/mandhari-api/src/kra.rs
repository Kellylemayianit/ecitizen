//! GavaConnect (KRA) client, written against the developer-portal docs:
//! token:  GET  {base}/v1/token/generate?grant_type=client_credentials  (Basic key:secret)
//!         -> {"access_token": "...", "expires_in": "3599"}
//! calls:  POST {base}/<path> with Bearer token and a JSON body.
use std::{collections::HashMap, time::{Duration, Instant}};

use serde::Deserialize;
use serde_json::{json, Map, Value};
use tokio::sync::RwLock;

use crate::{config::{creds_for, Creds}, error::AppError};

#[derive(Clone, Copy)]
pub enum Api { PinByPin, PinById, Station, TccCheck, ItExemption, Invoice, CustomsDecl }

impl Api {
    fn prefix(self) -> &'static str {
        match self {
            Api::PinByPin => "PIN_BY_PIN", Api::PinById => "PIN_BY_ID", Api::Station => "STATION",
            Api::TccCheck => "TCC_CHECK", Api::ItExemption => "IT_EXEMPTION", Api::Invoice => "INVOICE",
            Api::CustomsDecl => "CUSTOMS_DECL",
        }
    }
    fn path(self) -> &'static str {
        match self {
            Api::PinByPin => "/checker/v1/pinbypin",
            Api::PinById => "/checker/v1/pin",
            Api::Station => "/dtd/checker/v1/station",
            Api::TccCheck => "/v1/kra-tcc/validate",
            Api::ItExemption => "/checker/v1/itexemption",
            Api::Invoice => "/checker/v1/invoice",
            Api::CustomsDecl => "/checker/v1/simple/declaration",
        }
    }
}

#[derive(Deserialize)]
struct TokenResponse { access_token: String, expires_in: Value }
struct Cached { value: String, expires_at: Instant }

pub struct KraClient {
    http: reqwest::Client,
    base_url: String,
    tokens: RwLock<HashMap<String, Cached>>, // one token per app (consumer key)
}

fn text(v: &Value) -> Value {
    match v {
        Value::Null => json!("-"),
        Value::String(s) => json!(s.trim()),
        other => json!(other.to_string()),
    }
}
fn first<'a>(v: &'a Value, keys: &[&str]) -> Option<&'a str> {
    keys.iter().find_map(|k| v.get(*k).and_then(Value::as_str))
}
/// Business errors come back as {"Status":"NOK"...} or {"ErrorCode":...}.
fn check_ok(v: &Value) -> Result<(), AppError> {
    let status = first(v, &["Status", "status"]).unwrap_or("");
    let failed = status.eq_ignore_ascii_case("NOK") || status.eq_ignore_ascii_case("ERROR")
        || v.get("ErrorCode").is_some() || v.get("errorCode").is_some();
    if failed {
        let msg = first(v, &["Message", "ErrorMessage", "errorMessage", "responseDesc"]).unwrap_or("Not found");
        return Err(AppError::NotFound(msg.to_string()));
    }
    Ok(())
}
fn pick(src: &Value, fields: &[(&str, &str)]) -> Value {
    let mut m = Map::new();
    for (label, key) in fields { m.insert((*label).to_string(), text(&src[*key])); }
    Value::Object(m)
}

impl KraClient {
    pub fn new(base_url: String) -> Self {
        let http = reqwest::Client::builder().timeout(Duration::from_secs(15)).build().expect("http client");
        Self { http, base_url, tokens: RwLock::new(HashMap::new()) }
    }

    async fn token(&self, c: &Creds) -> Result<String, AppError> {
        if let Some(t) = self.tokens.read().await.get(&c.key) {
            if t.expires_at > Instant::now() { return Ok(t.value.clone()); }
        }
        let res = self.http
            .get(format!("{}/v1/token/generate", self.base_url))
            .query(&[("grant_type", "client_credentials")])
            .basic_auth(&c.key, Some(&c.secret))
            .send().await.map_err(|e| AppError::Upstream(format!("token request: {e}")))?;
        if !res.status().is_success() {
            return Err(AppError::Upstream(format!("token request failed: {}", res.status())));
        }
        let t: TokenResponse = res.json().await.map_err(|e| AppError::Upstream(format!("token body: {e}")))?;
        let secs = match &t.expires_in {
            Value::Number(n) => n.as_u64().unwrap_or(300),
            Value::String(s) => s.parse().unwrap_or(300),
            _ => 300,
        };
        self.tokens.write().await.insert(c.key.clone(), Cached {
            value: t.access_token.clone(),
            expires_at: Instant::now() + Duration::from_secs(secs.saturating_sub(30)),
        });
        Ok(t.access_token)
    }

    async fn call(&self, api: Api, body: Value) -> Result<Value, AppError> {
        let creds = creds_for(api.prefix()).ok_or_else(|| AppError::NotConfigured(format!("no credentials for {}", api.prefix())))?;
        let token = self.token(&creds).await?;
        let res = self.http.post(format!("{}{}", self.base_url, api.path())).bearer_auth(token).json(&body)
            .send().await.map_err(|e| AppError::Upstream(format!("{}: {e}", api.prefix())))?;
        let status = res.status();
        if status == reqwest::StatusCode::UNAUTHORIZED {
            self.tokens.write().await.remove(&creds.key); // force a fresh token next time
            return Err(AppError::Upstream(format!("{}: 401 from KRA", api.prefix())));
        }
        res.json().await.map_err(|e| AppError::Upstream(format!("{} body ({status}): {e}", api.prefix())))
    }

    /// PIN Checker by PIN.
    pub async fn pin_check(&self, pin: &str) -> Result<Value, AppError> {
        let v = self.call(Api::PinByPin, json!({ "KRAPIN": pin })).await?;
        check_ok(&v)?;
        Ok(pick(&v["PINDATA"], &[("PIN", "KRAPIN"), ("Name", "Name"), ("Taxpayer type", "TypeOfTaxpayer"), ("PIN status", "StatusOfPIN")]))
    }

    /// PIN Checker by ID. Not exposed on a public route: it turns any ID number into a PIN and a name.
    #[allow(dead_code)]
    pub async fn pin_by_id(&self, taxpayer_type: &str, id: &str) -> Result<Value, AppError> {
        let v = self.call(Api::PinById, json!({ "TaxpayerType": taxpayer_type, "TaxpayerID": id })).await?;
        check_ok(&v)?;
        Ok(pick(&v, &[("PIN", "TaxpayerPIN"), ("Name", "TaxpayerName")]))
    }

    /// Know KRA Tax Service Office.
    pub async fn station(&self, pin: &str) -> Result<Value, AppError> {
        let v = self.call(Api::Station, json!({ "kraPin": pin })).await?;
        check_ok(&v)?;
        Ok(pick(&v["STATIONDATA"], &[("PIN", "kraPin"), ("Tax station", "stationName")]))
    }

    /// Tax Compliance Certificate checker.
    pub async fn tcc_check(&self, pin: &str, tcc: &str) -> Result<Value, AppError> {
        let v = self.call(Api::TccCheck, json!({ "kraPIN": pin, "tccNumber": tcc })).await?;
        check_ok(&v)?;
        Ok(pick(&v["TCCData"], &[("PIN", "KRAPIN"), ("Certificate", "TCCNumber"), ("Status", "TCCStatus"), ("Issued", "TCCIssueDate"), ("Expires", "TCCExpiryDate")]))
    }

    /// Income Tax exemption checker. Codes: 200 valid, 600 invalid PIN, 900 no valid certificate.
    pub async fn it_exemption(&self, pin: &str) -> Result<Value, AppError> {
        let v = self.call(Api::ItExemption, json!({ "pin": pin })).await?;
        match first(&v, &["response_code"]).unwrap_or("") {
            "200" => Ok(json!({ "Exempt": "Yes", "Certificate": text(&v["cert_no"]), "Effective from": text(&v["cert_eff_date"]), "Expires": text(&v["cert_expiry_date"]) })),
            "600" => Err(AppError::NotFound("Invalid KRA PIN".into())),
            _ => Ok(json!({ "Exempt": "No", "Result": text(&v["response_message"]) })),
        }
    }

    /// Invoice checker (eTIMS). Date format: YYYY-MM-DD.
    pub async fn invoice(&self, number: &str, date: &str) -> Result<Value, AppError> {
        let v = self.call(Api::Invoice, json!({ "invoiceNumber": number, "invoiceDate": date })).await?;
        if v["responseCode"].as_i64() == Some(40001) { return Err(AppError::NotFound("Invoice not found".into())); }
        if v["status"].as_str() != Some("OK") { return Err(AppError::Upstream(format!("invoice: {v}"))); }
        Ok(pick(&v["invoiceDetails"], &[("Supplier", "supplierName"), ("Supplier PIN", "supplierPIN"), ("Invoice date", "invoiceDate"), ("Total amount", "totalInvoiceAmount"), ("Tax amount", "totalTaxAmount"), ("Control unit number", "controlUnitInvoiceNumber")]))
    }

    /// Customs declaration status. R00001 means no data found.
    pub async fn customs_status(&self, declaration: &str) -> Result<Value, AppError> {
        let v = self.call(Api::CustomsDecl, json!({ "DeclarationNo": declaration })).await?;
        if first(&v, &["response_code"]) == Some("R00001") { return Err(AppError::NotFound("No declaration found".into())); }
        Ok(json!({ "Declaration": declaration, "Status": text(&v["status"]) }))
    }
}
