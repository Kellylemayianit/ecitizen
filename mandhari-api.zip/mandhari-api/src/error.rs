use axum::{http::StatusCode, response::{IntoResponse, Response}, Json};
use serde_json::json;

#[derive(Debug, thiserror::Error)]
pub enum AppError {
    #[error("{0}")]
    BadRequest(String),
    #[error("{0}")]
    NotFound(String),
    #[error("not configured: {0}")]
    NotConfigured(String),
    #[error("upstream error: {0}")]
    Upstream(String),
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, message) = match &self {
            AppError::BadRequest(m) => (StatusCode::BAD_REQUEST, m.clone()),
            AppError::NotFound(m) => (StatusCode::NOT_FOUND, m.clone()),
            AppError::NotConfigured(m) => {
                tracing::error!("{m}");
                (StatusCode::SERVICE_UNAVAILABLE, "This service is not available yet".to_string())
            }
            AppError::Upstream(m) => {
                // Log the detail; never leak upstream internals to the client.
                tracing::error!("{m}");
                (StatusCode::BAD_GATEWAY, "The tax service is unavailable right now".to_string())
            }
        };
        (status, Json(json!({ "error": message }))).into_response()
    }
}
