mod config;
mod error;
mod kra;

use std::sync::Arc;

use axum::{
    extract::{Path, Query, State},
    http::{HeaderValue, Method},
    routing::get,
    Json, Router,
};
use serde::Deserialize;
use serde_json::Value;
use tower_http::{cors::CorsLayer, trace::TraceLayer};

use crate::{config::Config, error::AppError, kra::KraClient};

struct AppState {
    kra: KraClient,
}
type Shared = State<Arc<AppState>>;
type JsonResult = Result<Json<Value>, AppError>;

/// KRA PINs: "A" or "P", then 9 digits, then a letter (per the portal docs).
fn valid_pin(p: &str) -> bool {
    let b = p.as_bytes();
    b.len() == 11 && (b[0] == b'A' || b[0] == b'P') && b[1..10].iter().all(|c| c.is_ascii_digit()) && b[10].is_ascii_alphabetic()
}
fn pin(raw: String) -> Result<String, AppError> {
    let p = raw.trim().to_uppercase();
    if valid_pin(&p) { Ok(p) } else { Err(AppError::BadRequest("That does not look like a KRA PIN".into())) }
}
fn token_like(s: &str, what: &str) -> Result<String, AppError> {
    let s = s.trim();
    if !s.is_empty() && s.len() <= 40 && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '/' || c == '-') { Ok(s.to_string()) }
    else { Err(AppError::BadRequest(format!("Check the {what} and try again"))) }
}

async fn health() -> &'static str { "ok" }

// TODO before going public: require a signed-in session on every /v1 route and rate-limit per user.
// These lookups return taxpayer names for any PIN, so they must not be open to the internet.
async fn pin_check(State(s): Shared, Path(p): Path<String>) -> JsonResult { Ok(Json(s.kra.pin_check(&pin(p)?).await?)) }
async fn station(State(s): Shared, Path(p): Path<String>) -> JsonResult { Ok(Json(s.kra.station(&pin(p)?).await?)) }
async fn it_exemption(State(s): Shared, Path(p): Path<String>) -> JsonResult { Ok(Json(s.kra.it_exemption(&pin(p)?).await?)) }
async fn tcc_check(State(s): Shared, Path((p, t)): Path<(String, String)>) -> JsonResult {
    Ok(Json(s.kra.tcc_check(&pin(p)?, &token_like(&t, "certificate number")?).await?))
}
async fn customs(State(s): Shared, Path(d): Path<String>) -> JsonResult {
    Ok(Json(s.kra.customs_status(&token_like(&d, "declaration number")?).await?))
}

#[derive(Deserialize)]
struct InvoiceQuery { number: String, date: String }
async fn invoice(State(s): Shared, Query(q): Query<InvoiceQuery>) -> JsonResult {
    let d = q.date.trim();
    let ok = d.len() == 10 && d.char_indices().all(|(i, c)| if i == 4 || i == 7 { c == '-' } else { c.is_ascii_digit() });
    if !ok { return Err(AppError::BadRequest("Date must look like 2024-08-18".into())); }
    Ok(Json(s.kra.invoice(&token_like(&q.number, "invoice number")?, d).await?))
}

#[tokio::main]
async fn main() {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")))
        .init();

    let cfg = Config::from_env();
    let origin: HeaderValue = cfg.allowed_origin.parse().expect("ALLOWED_ORIGIN must be a valid origin");
    let state = Arc::new(AppState { kra: KraClient::new(cfg.kra_base_url.clone()) });

    let app = Router::new()
        .route("/health", get(health))
        .route("/v1/kra/pin/{pin}", get(pin_check))
        .route("/v1/kra/station/{pin}", get(station))
        .route("/v1/kra/it-exemption/{pin}", get(it_exemption))
        .route("/v1/kra/tcc/{pin}/{tcc}", get(tcc_check))
        .route("/v1/kra/customs/{declaration}", get(customs))
        .route("/v1/kra/invoice", get(invoice))
        .layer(CorsLayer::new().allow_origin(origin).allow_methods([Method::GET]))
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let listener = tokio::net::TcpListener::bind(&cfg.bind).await.expect("bind");
    tracing::info!("listening on {}", cfg.bind);
    axum::serve(listener, app).await.expect("server");
}
