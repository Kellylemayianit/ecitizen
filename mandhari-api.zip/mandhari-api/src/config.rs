use std::env;

#[derive(Clone)]
pub struct Creds {
    pub key: String,
    pub secret: String,
}

/// Looks up KRA_<PREFIX>_KEY / _SECRET, falling back to KRA_KEY / KRA_SECRET.
pub fn creds_for(prefix: &str) -> Option<Creds> {
    let pair = |k: String, s: String| Some(Creds { key: env::var(k).ok().filter(|v| !v.is_empty())?, secret: env::var(s).ok().filter(|v| !v.is_empty())? });
    pair(format!("KRA_{prefix}_KEY"), format!("KRA_{prefix}_SECRET")).or_else(|| pair("KRA_KEY".into(), "KRA_SECRET".into()))
}

#[derive(Clone)]
pub struct Config {
    pub bind: String,
    pub allowed_origin: String,
    pub kra_base_url: String,
}

impl Config {
    pub fn from_env() -> Self {
        Self {
            bind: env::var("BIND").unwrap_or_else(|_| "0.0.0.0:8080".to_string()),
            allowed_origin: env::var("ALLOWED_ORIGIN").expect("missing environment variable ALLOWED_ORIGIN"),
            kra_base_url: env::var("KRA_BASE_URL").unwrap_or_else(|_| "https://sbx.kra.go.ke".to_string()).trim_end_matches('/').to_string(),
        }
    }
}
