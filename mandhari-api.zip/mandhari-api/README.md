# Mandhari API (Rust, Axum)

Citizen-facing KRA lookups through GavaConnect, written against the developer-portal docs.

## Routes (all GET)
- `/v1/kra/pin/{pin}` PIN checker by PIN
- `/v1/kra/station/{pin}` Know your KRA tax station
- `/v1/kra/it-exemption/{pin}` Income tax exemption checker
- `/v1/kra/tcc/{pin}/{tccNumber}` Tax Compliance Certificate checker
- `/v1/kra/invoice?number=...&date=YYYY-MM-DD` Invoice (eTIMS) checker
- `/v1/kra/customs/{declarationNo}` Customs declaration status

## Run
1. Install Rust, `cp .env.example .env`, fill in the credentials from "My Apps" on the developer portal (one app per API)
2. `cargo run`
3. Try a sandbox PIN from the docs: `curl localhost:8080/v1/kra/pin/A744610021G`
4. In the app set `EXPO_PUBLIC_API_URL=http://localhost:8080`, then `npx expo start -c`

## Decisions worth knowing
- Token flow follows the docs: `GET /v1/token/generate?grant_type=client_credentials` with Basic auth; tokens are cached per app and refreshed before they expire.
- PIN-by-ID (`pin_by_id` in `kra.rs`) has no public route on purpose: it resolves any ID number into a PIN and a name. Use it only for the signed-in, identity-verified user.
- Filing APIs (NIL return, TOT, TCC application) are not exposed yet. They act for a taxpayer, so they need real sessions and proof that the signed-in user owns the PIN first.
- The docs show a double slash in the production PIN URL; the client uses a single slash.

## Before going public
Sessions and auth on every route, per-user rate limits, Postgres, OTP delivery, audit logging, and an ODPC registration review (these routes return personal data).
